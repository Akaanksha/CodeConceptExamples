import UIKit

func work1ToBeDone() {
    let queue1 = DispatchQueue(label: "PERFORM_TASK_WITH_TEAM1")
    let queue2 = DispatchQueue(label: "PERFORM_TASK_WITH_TEAM2")
    
    queue1.async {
        for items in 1 ..< 4 {
            print("TEAM1 \(items)")
        }
    }
    
    queue2.async {
        for items in 1 ..< 4{
            print("TEAM2 \(items)")
        }
    }
    
}

func work2ToBeDone() {
    let queue1 = DispatchQueue(label: "PERFORM_TASK_WITH_TEAM1")
    let queue2 = DispatchQueue(label: "PERFORM_TASK_WITH_TEAM2")
    
    queue1.sync {
        for items in 1 ..< 4 {
            print("TEAM1 \(items)")
        }
    }
    
    queue2.sync {
        for items in 1 ..< 4{
            print("TEAM2 \(items)")
        }
    }
    
}

work1ToBeDone()
print("\n\nWork 2 \n\n")
work2ToBeDone()
